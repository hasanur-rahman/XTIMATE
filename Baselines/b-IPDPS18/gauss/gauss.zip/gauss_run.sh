python gauss.py gauss.txt 97104
